// Define the clock frequency (adjust according to your setup)
#define _XTAL_FREQ 8000000  // 8 MHz Crystal

void delay(unsigned int milliseconds) {
    unsigned int i;
    for (i = 0; i < milliseconds; i++);
}

void MotorDelay() {
    unsigned int a;
    for (a = 0; a < 270; a++);
}

void main() {
    char received_char;

    // Initialize UART at 9600 baud
    UART1_Init(9600);
    delay_ms(100); // Allow time for initialization


    UART1_Write_Text("Ready to receive commands\n\r");

    // Configure PORTC and PORTB as output
    TRISC = 0x00; // Set all pins on PORTC as output
    TRISB = 0x00; // Set all pins on PORTB as output
    PORTC = 0x00; // Turn off all motors initially
    PORTB = 0x00; // Turn off all motors initially

    while (1) {
    unsigned int j=0;
        if (UART1_Data_Ready()) { // Check if data is available
            received_char = UART1_Read(); // Read the received character

            // Determine motor movement based on received character
            switch (received_char) {
                case 'F':
                    PORTC = 0x02; // Move motor X right
                    for (j = 0; j < 50; j++) {
                        PORTC = PORTC & 0xFE; // Step_X (RC0) = 0
                        MotorDelay();
                        PORTC = PORTC | 0x01; // Step_X (RC0) = 1
                        MotorDelay();
                    }
                    break;
                case 'L':
                    PORTC = 0x08; // Move motor Y up
                    for (j = 0; j < 50; j++) {
                        PORTC = PORTC & 0xFB; // Step_Y (RC2) = 0
                        MotorDelay();
                        PORTC = PORTC | 0x04; // Step_Y (RC2) = 1
                        MotorDelay();
                    }
                    break;
                case 'B':
                    PORTC = 0x20; // Move motor Z up
                    for (j = 0; j < 50; j++) {
                        PORTC = PORTC & 0xEF; // Step_Z (RC4) = 0
                        MotorDelay();
                        PORTC = PORTC | 0x10; // Step_Z (RC4) = 1
                        MotorDelay();
                    }
                    break;
                case 'U':
                    PORTB = 0x20; // Move motor W up
                    for (j = 0; j < 50; j++) {
                        PORTB = PORTB & 0xEF; // Step_W (RB4) = 0
                        MotorDelay();
                        PORTB = PORTB | 0x10; // Step_W (RB4) = 1
                        MotorDelay();
                    }
                    break;
                case 'D':
                    PORTB = 0x02; // Move motor D right
                    for (j = 0; j < 50; j++) {
                        PORTB = PORTB & 0xFE; // Step_D (RB0) = 0
                        MotorDelay();
                        PORTB = PORTB | 0x01; // Step_D (RB0) = 1
                        MotorDelay();
                    }
                    break;
                case 'R':
                    PORTB = 0x08; // Move motor F up
                    for (j = 0; j < 50; j++) {
                        PORTB = PORTB & 0xFB; // Step_F (RB2) = 0
                        MotorDelay();
                        PORTB = PORTB | 0x04; // Step_F (RB2) = 1
                        MotorDelay();
                    }
                    break;
                    case 'f':
                    PORTC = 0x00; // Move motor X right
                    for (j = 0; j < 50; j++) {
                        PORTC = PORTC & 0xFE; // Step_X (RC0) = 0
                        MotorDelay();
                        PORTC = PORTC | 0x01; // Step_X (RC0) = 1
                        MotorDelay();
                    }
                    break;
                case 'l':
                    PORTC = 0x00; // Move motor Y up
                    for (j = 0; j < 50; j++) {
                        PORTC = PORTC & 0xFB; // Step_Y (RC2) = 0
                        MotorDelay();
                        PORTC = PORTC | 0x04; // Step_Y (RC2) = 1
                        MotorDelay();
                    }
                    break;
                case 'b':
                    PORTC = 0x00; // Move motor Z up
                    for (j = 0; j < 50; j++) {
                        PORTC = PORTC & 0xEF; // Step_Z (RC4) = 0
                        MotorDelay();
                        PORTC = PORTC | 0x10; // Step_Z (RC4) = 1
                        MotorDelay();
                    }
                    break;
                case 'u':
                    PORTB = 0x00; // Move motor W up
                    for (j = 0; j < 50; j++) {
                        PORTB = PORTB & 0xEF; // Step_W (RB4) = 0
                        MotorDelay();
                        PORTB = PORTB | 0x10; // Step_W (RB4) = 1
                        MotorDelay();
                    }
                    break;
                case 'd':
                    PORTB = 0x00; // Move motor D right
                    for (j = 0; j < 50; j++) {
                        PORTB = PORTB & 0xFE; // Step_D (RB0) = 0
                        MotorDelay();
                        PORTB = PORTB | 0x01; // Step_D (RB0) = 1
                        MotorDelay();
                    }
                    break;
                case 'r':
                    PORTB = 0x00; // Move motor F up
                    for (j = 0; j < 50; j++) {
                        PORTB = PORTB & 0xFB; // Step_F (RB2) = 0
                        MotorDelay();
                        PORTB = PORTB | 0x04; // Step_F (RB2) = 1
                        MotorDelay();
                    }
                    break;
                default:
                    PORTC = 0x00; // Turn off all motors for unrecognized characters
                    PORTB = 0x00; // Turn off all motors for unrecognized characters
                    break;
            }
        }
    }
}